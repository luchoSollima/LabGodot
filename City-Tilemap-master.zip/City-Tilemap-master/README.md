<h1>Ejemplo para usar tilemaps </h1>

![GOpjp5sX0AABa8F](https://github.com/Matjanikow/City-Tilemap/assets/13339287/b80248ac-9dd2-47e7-9d4f-d2ee63c8cacf)
